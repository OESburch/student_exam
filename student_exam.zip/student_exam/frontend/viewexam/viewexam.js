angular.module( 'sample.viewexam', [
  'ui.router',
  'angular-storage'
])
.config(function($stateProvider) {
  $stateProvider.state('viewexam', {
    url: '/viewexam',
    controller: 'ViewExamCtrl',
    templateUrl: 'viewexam/viewexam.html',
    data: {
      requiresLogin: true
    }
  });
})
.controller( 'ViewExamCtrl', function ViewExamController( $scope, $http, store, $state) {


});
